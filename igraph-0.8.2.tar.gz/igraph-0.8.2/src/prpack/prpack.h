#ifndef PRPACK
#define PRPACK

#include "prpack_csc.h"
#include "prpack_csr.h"
#include "prpack_edge_list.h"
#include "prpack_base_graph.h"
#include "prpack_solver.h"
#include "prpack_result.h"

#endif
